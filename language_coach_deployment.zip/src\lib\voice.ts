/**
 * Voice Synthesis Service
 * Wrapper around Web Speech API for Text-to-Speech
 */

export interface VoiceOptions {
    rate?: number;  // 0.1 to 10
    pitch?: number; // 0 to 2
    volume?: number; // 0 to 1
    voice?: SpeechSynthesisVoice | null;
}

class VoiceService {
    private synthesis: SpeechSynthesis | null = null;
    private voices: SpeechSynthesisVoice[] = [];

    constructor() {
        if (typeof window !== 'undefined' && window.speechSynthesis) {
            this.synthesis = window.speechSynthesis;
            this.loadVoices(); // Initial load

            // Chrome loads voices asynchronously
            if (window.speechSynthesis.onvoiceschanged !== undefined) {
                window.speechSynthesis.onvoiceschanged = () => this.loadVoices();
            }
        }
    }

    private loadVoices() {
        if (!this.synthesis) return;
        this.voices = this.synthesis.getVoices();
    }

    public getVoices(): SpeechSynthesisVoice[] {
        return this.voices;
    }

    public getVoiceForLanguage(langCode: string): SpeechSynthesisVoice | null {
        // 1. Try exact match (e.g., 'es-ES')
        let voice = this.voices.find(v => v.lang === langCode);

        // 2. Try Google Cloud voice for that language (better quality)
        if (!voice) {
            voice = this.voices.find(v => v.lang.startsWith(langCode.split('-')[0]) && v.name.includes('Google'));
        }

        // 3. Try any voice matching the language code prefix (e.g., 'es' matches 'es-MX')
        if (!voice) {
            const shortCode = langCode.split('-')[0];
            voice = this.voices.find(v => v.lang.startsWith(shortCode));
        }

        // 4. Microsoft voices (common on Windows)
        if (!voice) {
            const shortCode = langCode.split('-')[0];
            voice = this.voices.find(v => v.lang.startsWith(shortCode) && v.name.includes('Microsoft'));
        }

        return voice || null;
    }

    public speak(text: string, langCode: string, options: VoiceOptions = {}) {
        if (!this.synthesis) {
            console.error('[VoiceService] SpeechSynthesis not supported');
            return;
        }

        // Cancel current speech to prevent overlapping
        this.synthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = langCode;
        utterance.rate = options.rate || 1.0;
        utterance.pitch = options.pitch || 1.0;
        utterance.volume = options.volume || 1.0;

        const voice = options.voice || this.getVoiceForLanguage(langCode);

        if (!voice) {
            console.warn(`[VoiceService] No voice found for language: ${langCode}. Available voices:`, this.voices.length);
            // Attempt fallback to first available if strictly necessary, or just fail silent with log
        } else {
            console.log(`[VoiceService] Speaking with voice: ${voice.name} (${voice.lang})`);
            utterance.voice = voice;
        }

        this.synthesis.speak(utterance);
    }

    public cancel() {
        if (this.synthesis) {
            this.synthesis.cancel();
        }
    }
}

// Singleton instance
export const voiceService = new VoiceService();
